// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package data_integration4.copy_of_transparencesantemain_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: Copy_of_Transparencesantemain Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class Copy_of_Transparencesantemain implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Copy_of_Transparencesantemain";
	private final String projectName = "DATA_INTEGRATION4";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Copy_of_Transparencesantemain.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Copy_of_Transparencesantemain.this,
									new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[0];
		static byte[] commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String token;

		public String getToken() {
			return this.token;
		}

		public String entreprise_id;

		public String getEntreprise_id() {
			return this.entreprise_id;
		}

		public String lien_interet;

		public String getLien_interet() {
			return this.lien_interet;
		}

		public String identifiant_unique;

		public String getIdentifiant_unique() {
			return this.identifiant_unique;
		}

		public String convention_liee;

		public String getConvention_liee() {
			return this.convention_liee;
		}

		public String motif_lien_interet_code;

		public String getMotif_lien_interet_code() {
			return this.motif_lien_interet_code;
		}

		public String motif_lien_interet;

		public String getMotif_lien_interet() {
			return this.motif_lien_interet;
		}

		public String autre_motif;

		public String getAutre_motif() {
			return this.autre_motif;
		}

		public String information_evenement;

		public String getInformation_evenement() {
			return this.information_evenement;
		}

		public String montant;

		public String getMontant() {
			return this.montant;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String date_debut;

		public String getDate_debut() {
			return this.date_debut;
		}

		public String date_fin;

		public String getDate_fin() {
			return this.date_fin;
		}

		public String id_beneficiaire;

		public String getId_beneficiaire() {
			return this.id_beneficiaire;
		}

		public String identite;

		public String getIdentite() {
			return this.identite;
		}

		public String prenom;

		public String getPrenom() {
			return this.prenom;
		}

		public String beneficiaire_categorie_code;

		public String getBeneficiaire_categorie_code() {
			return this.beneficiaire_categorie_code;
		}

		public String beneficiaire_categorie;

		public String getBeneficiaire_categorie() {
			return this.beneficiaire_categorie;
		}

		public String beneficiaire_type_code;

		public String getBeneficiaire_type_code() {
			return this.beneficiaire_type_code;
		}

		public String beneficiaire_type;

		public String getBeneficiaire_type() {
			return this.beneficiaire_type;
		}

		public String beneficiaire_identifiant;

		public String getBeneficiaire_identifiant() {
			return this.beneficiaire_identifiant;
		}

		public String beneficiaire_profession_code;

		public String getBeneficiaire_profession_code() {
			return this.beneficiaire_profession_code;
		}

		public String profession_libelle;

		public String getProfession_libelle() {
			return this.profession_libelle;
		}

		public String structure_exercice;

		public String getStructure_exercice() {
			return this.structure_exercice;
		}

		public String pays_code;

		public String getPays_code() {
			return this.pays_code;
		}

		public String adresse;

		public String getAdresse() {
			return this.adresse;
		}

		public String code_postal;

		public String getCode_postal() {
			return this.code_postal;
		}

		public String ville;

		public String getVille() {
			return this.ville;
		}

		public String demande_de_rectification;

		public String getDemande_de_rectification() {
			return this.demande_de_rectification;
		}

		public String statut;

		public String getStatut() {
			return this.statut;
		}

		public String date_publication;

		public String getDate_publication() {
			return this.date_publication;
		}

		public String date_transmission;

		public String getDate_transmission() {
			return this.date_transmission;
		}

		public String raison_sociale;

		public String getRaison_sociale() {
			return this.raison_sociale;
		}

		public String secteur_activite;

		public String getSecteur_activite() {
			return this.secteur_activite;
		}

		public String entr_ville;

		public String getEntr_ville() {
			return this.entr_ville;
		}

		public String entr_dep_name;

		public String getEntr_dep_name() {
			return this.entr_dep_name;
		}

		public String entr_reg_name;

		public String getEntr_reg_name() {
			return this.entr_reg_name;
		}

		public String entreprise_nom_pays;

		public String getEntreprise_nom_pays() {
			return this.entreprise_nom_pays;
		}

		public String mere_id;

		public String getMere_id() {
			return this.mere_id;
		}

		public String code_postal_entreprise;

		public String getCode_postal_entreprise() {
			return this.code_postal_entreprise;
		}

		public String numero_siren;

		public String getNumero_siren() {
			return this.numero_siren;
		}

		public String ville_sanscedex;

		public String getVille_sanscedex() {
			return this.ville_sanscedex;
		}

		public String geom;

		public String getGeom() {
			return this.geom;
		}

		public String com_name;

		public String getCom_name() {
			return this.com_name;
		}

		public String com_code;

		public String getCom_code() {
			return this.com_code;
		}

		public String epci_name;

		public String getEpci_name() {
			return this.epci_name;
		}

		public String epci_code;

		public String getEpci_code() {
			return this.epci_code;
		}

		public String dep_code;

		public String getDep_code() {
			return this.dep_code;
		}

		public String dep_name;

		public String getDep_name() {
			return this.dep_name;
		}

		public String reg_code;

		public String getReg_code() {
			return this.reg_code;
		}

		public String reg_name;

		public String getReg_name() {
			return this.reg_name;
		}

		public String beneficiaire_nom_prenom_com_name;

		public String getBeneficiaire_nom_prenom_com_name() {
			return this.beneficiaire_nom_prenom_com_name;
		}

		public String semestre_annee;

		public String getSemestre_annee() {
			return this.semestre_annee;
		}

		public String beneficiaire_nom_pays;

		public String getBeneficiaire_nom_pays() {
			return this.beneficiaire_nom_pays;
		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length) {
					if (length < 1024 && commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length == 0) {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[1024];
					} else {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length);
				strReturn = new String(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length) {
					if (length < 1024 && commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length == 0) {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[1024];
					} else {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length);
				strReturn = new String(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.token = readString(dis);

					this.entreprise_id = readString(dis);

					this.lien_interet = readString(dis);

					this.identifiant_unique = readString(dis);

					this.convention_liee = readString(dis);

					this.motif_lien_interet_code = readString(dis);

					this.motif_lien_interet = readString(dis);

					this.autre_motif = readString(dis);

					this.information_evenement = readString(dis);

					this.montant = readString(dis);

					this.date = readString(dis);

					this.date_debut = readString(dis);

					this.date_fin = readString(dis);

					this.id_beneficiaire = readString(dis);

					this.identite = readString(dis);

					this.prenom = readString(dis);

					this.beneficiaire_categorie_code = readString(dis);

					this.beneficiaire_categorie = readString(dis);

					this.beneficiaire_type_code = readString(dis);

					this.beneficiaire_type = readString(dis);

					this.beneficiaire_identifiant = readString(dis);

					this.beneficiaire_profession_code = readString(dis);

					this.profession_libelle = readString(dis);

					this.structure_exercice = readString(dis);

					this.pays_code = readString(dis);

					this.adresse = readString(dis);

					this.code_postal = readString(dis);

					this.ville = readString(dis);

					this.demande_de_rectification = readString(dis);

					this.statut = readString(dis);

					this.date_publication = readString(dis);

					this.date_transmission = readString(dis);

					this.raison_sociale = readString(dis);

					this.secteur_activite = readString(dis);

					this.entr_ville = readString(dis);

					this.entr_dep_name = readString(dis);

					this.entr_reg_name = readString(dis);

					this.entreprise_nom_pays = readString(dis);

					this.mere_id = readString(dis);

					this.code_postal_entreprise = readString(dis);

					this.numero_siren = readString(dis);

					this.ville_sanscedex = readString(dis);

					this.geom = readString(dis);

					this.com_name = readString(dis);

					this.com_code = readString(dis);

					this.epci_name = readString(dis);

					this.epci_code = readString(dis);

					this.dep_code = readString(dis);

					this.dep_name = readString(dis);

					this.reg_code = readString(dis);

					this.reg_name = readString(dis);

					this.beneficiaire_nom_prenom_com_name = readString(dis);

					this.semestre_annee = readString(dis);

					this.beneficiaire_nom_pays = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.token = readString(dis);

					this.entreprise_id = readString(dis);

					this.lien_interet = readString(dis);

					this.identifiant_unique = readString(dis);

					this.convention_liee = readString(dis);

					this.motif_lien_interet_code = readString(dis);

					this.motif_lien_interet = readString(dis);

					this.autre_motif = readString(dis);

					this.information_evenement = readString(dis);

					this.montant = readString(dis);

					this.date = readString(dis);

					this.date_debut = readString(dis);

					this.date_fin = readString(dis);

					this.id_beneficiaire = readString(dis);

					this.identite = readString(dis);

					this.prenom = readString(dis);

					this.beneficiaire_categorie_code = readString(dis);

					this.beneficiaire_categorie = readString(dis);

					this.beneficiaire_type_code = readString(dis);

					this.beneficiaire_type = readString(dis);

					this.beneficiaire_identifiant = readString(dis);

					this.beneficiaire_profession_code = readString(dis);

					this.profession_libelle = readString(dis);

					this.structure_exercice = readString(dis);

					this.pays_code = readString(dis);

					this.adresse = readString(dis);

					this.code_postal = readString(dis);

					this.ville = readString(dis);

					this.demande_de_rectification = readString(dis);

					this.statut = readString(dis);

					this.date_publication = readString(dis);

					this.date_transmission = readString(dis);

					this.raison_sociale = readString(dis);

					this.secteur_activite = readString(dis);

					this.entr_ville = readString(dis);

					this.entr_dep_name = readString(dis);

					this.entr_reg_name = readString(dis);

					this.entreprise_nom_pays = readString(dis);

					this.mere_id = readString(dis);

					this.code_postal_entreprise = readString(dis);

					this.numero_siren = readString(dis);

					this.ville_sanscedex = readString(dis);

					this.geom = readString(dis);

					this.com_name = readString(dis);

					this.com_code = readString(dis);

					this.epci_name = readString(dis);

					this.epci_code = readString(dis);

					this.dep_code = readString(dis);

					this.dep_name = readString(dis);

					this.reg_code = readString(dis);

					this.reg_name = readString(dis);

					this.beneficiaire_nom_prenom_com_name = readString(dis);

					this.semestre_annee = readString(dis);

					this.beneficiaire_nom_pays = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.token, dos);

				// String

				writeString(this.entreprise_id, dos);

				// String

				writeString(this.lien_interet, dos);

				// String

				writeString(this.identifiant_unique, dos);

				// String

				writeString(this.convention_liee, dos);

				// String

				writeString(this.motif_lien_interet_code, dos);

				// String

				writeString(this.motif_lien_interet, dos);

				// String

				writeString(this.autre_motif, dos);

				// String

				writeString(this.information_evenement, dos);

				// String

				writeString(this.montant, dos);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.date_debut, dos);

				// String

				writeString(this.date_fin, dos);

				// String

				writeString(this.id_beneficiaire, dos);

				// String

				writeString(this.identite, dos);

				// String

				writeString(this.prenom, dos);

				// String

				writeString(this.beneficiaire_categorie_code, dos);

				// String

				writeString(this.beneficiaire_categorie, dos);

				// String

				writeString(this.beneficiaire_type_code, dos);

				// String

				writeString(this.beneficiaire_type, dos);

				// String

				writeString(this.beneficiaire_identifiant, dos);

				// String

				writeString(this.beneficiaire_profession_code, dos);

				// String

				writeString(this.profession_libelle, dos);

				// String

				writeString(this.structure_exercice, dos);

				// String

				writeString(this.pays_code, dos);

				// String

				writeString(this.adresse, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.ville, dos);

				// String

				writeString(this.demande_de_rectification, dos);

				// String

				writeString(this.statut, dos);

				// String

				writeString(this.date_publication, dos);

				// String

				writeString(this.date_transmission, dos);

				// String

				writeString(this.raison_sociale, dos);

				// String

				writeString(this.secteur_activite, dos);

				// String

				writeString(this.entr_ville, dos);

				// String

				writeString(this.entr_dep_name, dos);

				// String

				writeString(this.entr_reg_name, dos);

				// String

				writeString(this.entreprise_nom_pays, dos);

				// String

				writeString(this.mere_id, dos);

				// String

				writeString(this.code_postal_entreprise, dos);

				// String

				writeString(this.numero_siren, dos);

				// String

				writeString(this.ville_sanscedex, dos);

				// String

				writeString(this.geom, dos);

				// String

				writeString(this.com_name, dos);

				// String

				writeString(this.com_code, dos);

				// String

				writeString(this.epci_name, dos);

				// String

				writeString(this.epci_code, dos);

				// String

				writeString(this.dep_code, dos);

				// String

				writeString(this.dep_name, dos);

				// String

				writeString(this.reg_code, dos);

				// String

				writeString(this.reg_name, dos);

				// String

				writeString(this.beneficiaire_nom_prenom_com_name, dos);

				// String

				writeString(this.semestre_annee, dos);

				// String

				writeString(this.beneficiaire_nom_pays, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.token, dos);

				// String

				writeString(this.entreprise_id, dos);

				// String

				writeString(this.lien_interet, dos);

				// String

				writeString(this.identifiant_unique, dos);

				// String

				writeString(this.convention_liee, dos);

				// String

				writeString(this.motif_lien_interet_code, dos);

				// String

				writeString(this.motif_lien_interet, dos);

				// String

				writeString(this.autre_motif, dos);

				// String

				writeString(this.information_evenement, dos);

				// String

				writeString(this.montant, dos);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.date_debut, dos);

				// String

				writeString(this.date_fin, dos);

				// String

				writeString(this.id_beneficiaire, dos);

				// String

				writeString(this.identite, dos);

				// String

				writeString(this.prenom, dos);

				// String

				writeString(this.beneficiaire_categorie_code, dos);

				// String

				writeString(this.beneficiaire_categorie, dos);

				// String

				writeString(this.beneficiaire_type_code, dos);

				// String

				writeString(this.beneficiaire_type, dos);

				// String

				writeString(this.beneficiaire_identifiant, dos);

				// String

				writeString(this.beneficiaire_profession_code, dos);

				// String

				writeString(this.profession_libelle, dos);

				// String

				writeString(this.structure_exercice, dos);

				// String

				writeString(this.pays_code, dos);

				// String

				writeString(this.adresse, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.ville, dos);

				// String

				writeString(this.demande_de_rectification, dos);

				// String

				writeString(this.statut, dos);

				// String

				writeString(this.date_publication, dos);

				// String

				writeString(this.date_transmission, dos);

				// String

				writeString(this.raison_sociale, dos);

				// String

				writeString(this.secteur_activite, dos);

				// String

				writeString(this.entr_ville, dos);

				// String

				writeString(this.entr_dep_name, dos);

				// String

				writeString(this.entr_reg_name, dos);

				// String

				writeString(this.entreprise_nom_pays, dos);

				// String

				writeString(this.mere_id, dos);

				// String

				writeString(this.code_postal_entreprise, dos);

				// String

				writeString(this.numero_siren, dos);

				// String

				writeString(this.ville_sanscedex, dos);

				// String

				writeString(this.geom, dos);

				// String

				writeString(this.com_name, dos);

				// String

				writeString(this.com_code, dos);

				// String

				writeString(this.epci_name, dos);

				// String

				writeString(this.epci_code, dos);

				// String

				writeString(this.dep_code, dos);

				// String

				writeString(this.dep_name, dos);

				// String

				writeString(this.reg_code, dos);

				// String

				writeString(this.reg_name, dos);

				// String

				writeString(this.beneficiaire_nom_prenom_com_name, dos);

				// String

				writeString(this.semestre_annee, dos);

				// String

				writeString(this.beneficiaire_nom_pays, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",token=" + token);
			sb.append(",entreprise_id=" + entreprise_id);
			sb.append(",lien_interet=" + lien_interet);
			sb.append(",identifiant_unique=" + identifiant_unique);
			sb.append(",convention_liee=" + convention_liee);
			sb.append(",motif_lien_interet_code=" + motif_lien_interet_code);
			sb.append(",motif_lien_interet=" + motif_lien_interet);
			sb.append(",autre_motif=" + autre_motif);
			sb.append(",information_evenement=" + information_evenement);
			sb.append(",montant=" + montant);
			sb.append(",date=" + date);
			sb.append(",date_debut=" + date_debut);
			sb.append(",date_fin=" + date_fin);
			sb.append(",id_beneficiaire=" + id_beneficiaire);
			sb.append(",identite=" + identite);
			sb.append(",prenom=" + prenom);
			sb.append(",beneficiaire_categorie_code=" + beneficiaire_categorie_code);
			sb.append(",beneficiaire_categorie=" + beneficiaire_categorie);
			sb.append(",beneficiaire_type_code=" + beneficiaire_type_code);
			sb.append(",beneficiaire_type=" + beneficiaire_type);
			sb.append(",beneficiaire_identifiant=" + beneficiaire_identifiant);
			sb.append(",beneficiaire_profession_code=" + beneficiaire_profession_code);
			sb.append(",profession_libelle=" + profession_libelle);
			sb.append(",structure_exercice=" + structure_exercice);
			sb.append(",pays_code=" + pays_code);
			sb.append(",adresse=" + adresse);
			sb.append(",code_postal=" + code_postal);
			sb.append(",ville=" + ville);
			sb.append(",demande_de_rectification=" + demande_de_rectification);
			sb.append(",statut=" + statut);
			sb.append(",date_publication=" + date_publication);
			sb.append(",date_transmission=" + date_transmission);
			sb.append(",raison_sociale=" + raison_sociale);
			sb.append(",secteur_activite=" + secteur_activite);
			sb.append(",entr_ville=" + entr_ville);
			sb.append(",entr_dep_name=" + entr_dep_name);
			sb.append(",entr_reg_name=" + entr_reg_name);
			sb.append(",entreprise_nom_pays=" + entreprise_nom_pays);
			sb.append(",mere_id=" + mere_id);
			sb.append(",code_postal_entreprise=" + code_postal_entreprise);
			sb.append(",numero_siren=" + numero_siren);
			sb.append(",ville_sanscedex=" + ville_sanscedex);
			sb.append(",geom=" + geom);
			sb.append(",com_name=" + com_name);
			sb.append(",com_code=" + com_code);
			sb.append(",epci_name=" + epci_name);
			sb.append(",epci_code=" + epci_code);
			sb.append(",dep_code=" + dep_code);
			sb.append(",dep_name=" + dep_name);
			sb.append(",reg_code=" + reg_code);
			sb.append(",reg_name=" + reg_name);
			sb.append(",beneficiaire_nom_prenom_com_name=" + beneficiaire_nom_prenom_com_name);
			sb.append(",semestre_annee=" + semestre_annee);
			sb.append(",beneficiaire_nom_pays=" + beneficiaire_nom_pays);
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[0];
		static byte[] commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public String token;

		public String getToken() {
			return this.token;
		}

		public String entreprise_id;

		public String getEntreprise_id() {
			return this.entreprise_id;
		}

		public String lien_interet;

		public String getLien_interet() {
			return this.lien_interet;
		}

		public String identifiant_unique;

		public String getIdentifiant_unique() {
			return this.identifiant_unique;
		}

		public String convention_liee;

		public String getConvention_liee() {
			return this.convention_liee;
		}

		public String motif_lien_interet_code;

		public String getMotif_lien_interet_code() {
			return this.motif_lien_interet_code;
		}

		public String motif_lien_interet;

		public String getMotif_lien_interet() {
			return this.motif_lien_interet;
		}

		public String autre_motif;

		public String getAutre_motif() {
			return this.autre_motif;
		}

		public String information_evenement;

		public String getInformation_evenement() {
			return this.information_evenement;
		}

		public String montant;

		public String getMontant() {
			return this.montant;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String date_debut;

		public String getDate_debut() {
			return this.date_debut;
		}

		public String date_fin;

		public String getDate_fin() {
			return this.date_fin;
		}

		public String id_beneficiaire;

		public String getId_beneficiaire() {
			return this.id_beneficiaire;
		}

		public String identite;

		public String getIdentite() {
			return this.identite;
		}

		public String prenom;

		public String getPrenom() {
			return this.prenom;
		}

		public String beneficiaire_categorie_code;

		public String getBeneficiaire_categorie_code() {
			return this.beneficiaire_categorie_code;
		}

		public String beneficiaire_categorie;

		public String getBeneficiaire_categorie() {
			return this.beneficiaire_categorie;
		}

		public String beneficiaire_type_code;

		public String getBeneficiaire_type_code() {
			return this.beneficiaire_type_code;
		}

		public String beneficiaire_type;

		public String getBeneficiaire_type() {
			return this.beneficiaire_type;
		}

		public String beneficiaire_identifiant;

		public String getBeneficiaire_identifiant() {
			return this.beneficiaire_identifiant;
		}

		public String beneficiaire_profession_code;

		public String getBeneficiaire_profession_code() {
			return this.beneficiaire_profession_code;
		}

		public String profession_libelle;

		public String getProfession_libelle() {
			return this.profession_libelle;
		}

		public String structure_exercice;

		public String getStructure_exercice() {
			return this.structure_exercice;
		}

		public String pays_code;

		public String getPays_code() {
			return this.pays_code;
		}

		public String adresse;

		public String getAdresse() {
			return this.adresse;
		}

		public String code_postal;

		public String getCode_postal() {
			return this.code_postal;
		}

		public String ville;

		public String getVille() {
			return this.ville;
		}

		public String demande_de_rectification;

		public String getDemande_de_rectification() {
			return this.demande_de_rectification;
		}

		public String statut;

		public String getStatut() {
			return this.statut;
		}

		public String date_publication;

		public String getDate_publication() {
			return this.date_publication;
		}

		public String date_transmission;

		public String getDate_transmission() {
			return this.date_transmission;
		}

		public String raison_sociale;

		public String getRaison_sociale() {
			return this.raison_sociale;
		}

		public String secteur_activite;

		public String getSecteur_activite() {
			return this.secteur_activite;
		}

		public String entr_ville;

		public String getEntr_ville() {
			return this.entr_ville;
		}

		public String entr_dep_name;

		public String getEntr_dep_name() {
			return this.entr_dep_name;
		}

		public String entr_reg_name;

		public String getEntr_reg_name() {
			return this.entr_reg_name;
		}

		public String entreprise_nom_pays;

		public String getEntreprise_nom_pays() {
			return this.entreprise_nom_pays;
		}

		public String mere_id;

		public String getMere_id() {
			return this.mere_id;
		}

		public String code_postal_entreprise;

		public String getCode_postal_entreprise() {
			return this.code_postal_entreprise;
		}

		public String numero_siren;

		public String getNumero_siren() {
			return this.numero_siren;
		}

		public String ville_sanscedex;

		public String getVille_sanscedex() {
			return this.ville_sanscedex;
		}

		public String geom;

		public String getGeom() {
			return this.geom;
		}

		public String com_name;

		public String getCom_name() {
			return this.com_name;
		}

		public String com_code;

		public String getCom_code() {
			return this.com_code;
		}

		public String epci_name;

		public String getEpci_name() {
			return this.epci_name;
		}

		public String epci_code;

		public String getEpci_code() {
			return this.epci_code;
		}

		public String dep_code;

		public String getDep_code() {
			return this.dep_code;
		}

		public String dep_name;

		public String getDep_name() {
			return this.dep_name;
		}

		public String reg_code;

		public String getReg_code() {
			return this.reg_code;
		}

		public String reg_name;

		public String getReg_name() {
			return this.reg_name;
		}

		public String beneficiaire_nom_prenom_com_name;

		public String getBeneficiaire_nom_prenom_com_name() {
			return this.beneficiaire_nom_prenom_com_name;
		}

		public String semestre_annee;

		public String getSemestre_annee() {
			return this.semestre_annee;
		}

		public String beneficiaire_nom_pays;

		public String getBeneficiaire_nom_pays() {
			return this.beneficiaire_nom_pays;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length) {
					if (length < 1024 && commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length == 0) {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[1024];
					} else {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length);
				strReturn = new String(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length) {
					if (length < 1024 && commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain.length == 0) {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[1024];
					} else {
						commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length);
				strReturn = new String(commonByteArray_DATA_INTEGRATION4_Copy_of_Transparencesantemain, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.token = readString(dis);

					this.entreprise_id = readString(dis);

					this.lien_interet = readString(dis);

					this.identifiant_unique = readString(dis);

					this.convention_liee = readString(dis);

					this.motif_lien_interet_code = readString(dis);

					this.motif_lien_interet = readString(dis);

					this.autre_motif = readString(dis);

					this.information_evenement = readString(dis);

					this.montant = readString(dis);

					this.date = readString(dis);

					this.date_debut = readString(dis);

					this.date_fin = readString(dis);

					this.id_beneficiaire = readString(dis);

					this.identite = readString(dis);

					this.prenom = readString(dis);

					this.beneficiaire_categorie_code = readString(dis);

					this.beneficiaire_categorie = readString(dis);

					this.beneficiaire_type_code = readString(dis);

					this.beneficiaire_type = readString(dis);

					this.beneficiaire_identifiant = readString(dis);

					this.beneficiaire_profession_code = readString(dis);

					this.profession_libelle = readString(dis);

					this.structure_exercice = readString(dis);

					this.pays_code = readString(dis);

					this.adresse = readString(dis);

					this.code_postal = readString(dis);

					this.ville = readString(dis);

					this.demande_de_rectification = readString(dis);

					this.statut = readString(dis);

					this.date_publication = readString(dis);

					this.date_transmission = readString(dis);

					this.raison_sociale = readString(dis);

					this.secteur_activite = readString(dis);

					this.entr_ville = readString(dis);

					this.entr_dep_name = readString(dis);

					this.entr_reg_name = readString(dis);

					this.entreprise_nom_pays = readString(dis);

					this.mere_id = readString(dis);

					this.code_postal_entreprise = readString(dis);

					this.numero_siren = readString(dis);

					this.ville_sanscedex = readString(dis);

					this.geom = readString(dis);

					this.com_name = readString(dis);

					this.com_code = readString(dis);

					this.epci_name = readString(dis);

					this.epci_code = readString(dis);

					this.dep_code = readString(dis);

					this.dep_name = readString(dis);

					this.reg_code = readString(dis);

					this.reg_name = readString(dis);

					this.beneficiaire_nom_prenom_com_name = readString(dis);

					this.semestre_annee = readString(dis);

					this.beneficiaire_nom_pays = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DATA_INTEGRATION4_Copy_of_Transparencesantemain) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.token = readString(dis);

					this.entreprise_id = readString(dis);

					this.lien_interet = readString(dis);

					this.identifiant_unique = readString(dis);

					this.convention_liee = readString(dis);

					this.motif_lien_interet_code = readString(dis);

					this.motif_lien_interet = readString(dis);

					this.autre_motif = readString(dis);

					this.information_evenement = readString(dis);

					this.montant = readString(dis);

					this.date = readString(dis);

					this.date_debut = readString(dis);

					this.date_fin = readString(dis);

					this.id_beneficiaire = readString(dis);

					this.identite = readString(dis);

					this.prenom = readString(dis);

					this.beneficiaire_categorie_code = readString(dis);

					this.beneficiaire_categorie = readString(dis);

					this.beneficiaire_type_code = readString(dis);

					this.beneficiaire_type = readString(dis);

					this.beneficiaire_identifiant = readString(dis);

					this.beneficiaire_profession_code = readString(dis);

					this.profession_libelle = readString(dis);

					this.structure_exercice = readString(dis);

					this.pays_code = readString(dis);

					this.adresse = readString(dis);

					this.code_postal = readString(dis);

					this.ville = readString(dis);

					this.demande_de_rectification = readString(dis);

					this.statut = readString(dis);

					this.date_publication = readString(dis);

					this.date_transmission = readString(dis);

					this.raison_sociale = readString(dis);

					this.secteur_activite = readString(dis);

					this.entr_ville = readString(dis);

					this.entr_dep_name = readString(dis);

					this.entr_reg_name = readString(dis);

					this.entreprise_nom_pays = readString(dis);

					this.mere_id = readString(dis);

					this.code_postal_entreprise = readString(dis);

					this.numero_siren = readString(dis);

					this.ville_sanscedex = readString(dis);

					this.geom = readString(dis);

					this.com_name = readString(dis);

					this.com_code = readString(dis);

					this.epci_name = readString(dis);

					this.epci_code = readString(dis);

					this.dep_code = readString(dis);

					this.dep_name = readString(dis);

					this.reg_code = readString(dis);

					this.reg_name = readString(dis);

					this.beneficiaire_nom_prenom_com_name = readString(dis);

					this.semestre_annee = readString(dis);

					this.beneficiaire_nom_pays = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.token, dos);

				// String

				writeString(this.entreprise_id, dos);

				// String

				writeString(this.lien_interet, dos);

				// String

				writeString(this.identifiant_unique, dos);

				// String

				writeString(this.convention_liee, dos);

				// String

				writeString(this.motif_lien_interet_code, dos);

				// String

				writeString(this.motif_lien_interet, dos);

				// String

				writeString(this.autre_motif, dos);

				// String

				writeString(this.information_evenement, dos);

				// String

				writeString(this.montant, dos);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.date_debut, dos);

				// String

				writeString(this.date_fin, dos);

				// String

				writeString(this.id_beneficiaire, dos);

				// String

				writeString(this.identite, dos);

				// String

				writeString(this.prenom, dos);

				// String

				writeString(this.beneficiaire_categorie_code, dos);

				// String

				writeString(this.beneficiaire_categorie, dos);

				// String

				writeString(this.beneficiaire_type_code, dos);

				// String

				writeString(this.beneficiaire_type, dos);

				// String

				writeString(this.beneficiaire_identifiant, dos);

				// String

				writeString(this.beneficiaire_profession_code, dos);

				// String

				writeString(this.profession_libelle, dos);

				// String

				writeString(this.structure_exercice, dos);

				// String

				writeString(this.pays_code, dos);

				// String

				writeString(this.adresse, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.ville, dos);

				// String

				writeString(this.demande_de_rectification, dos);

				// String

				writeString(this.statut, dos);

				// String

				writeString(this.date_publication, dos);

				// String

				writeString(this.date_transmission, dos);

				// String

				writeString(this.raison_sociale, dos);

				// String

				writeString(this.secteur_activite, dos);

				// String

				writeString(this.entr_ville, dos);

				// String

				writeString(this.entr_dep_name, dos);

				// String

				writeString(this.entr_reg_name, dos);

				// String

				writeString(this.entreprise_nom_pays, dos);

				// String

				writeString(this.mere_id, dos);

				// String

				writeString(this.code_postal_entreprise, dos);

				// String

				writeString(this.numero_siren, dos);

				// String

				writeString(this.ville_sanscedex, dos);

				// String

				writeString(this.geom, dos);

				// String

				writeString(this.com_name, dos);

				// String

				writeString(this.com_code, dos);

				// String

				writeString(this.epci_name, dos);

				// String

				writeString(this.epci_code, dos);

				// String

				writeString(this.dep_code, dos);

				// String

				writeString(this.dep_name, dos);

				// String

				writeString(this.reg_code, dos);

				// String

				writeString(this.reg_name, dos);

				// String

				writeString(this.beneficiaire_nom_prenom_com_name, dos);

				// String

				writeString(this.semestre_annee, dos);

				// String

				writeString(this.beneficiaire_nom_pays, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// String

				writeString(this.token, dos);

				// String

				writeString(this.entreprise_id, dos);

				// String

				writeString(this.lien_interet, dos);

				// String

				writeString(this.identifiant_unique, dos);

				// String

				writeString(this.convention_liee, dos);

				// String

				writeString(this.motif_lien_interet_code, dos);

				// String

				writeString(this.motif_lien_interet, dos);

				// String

				writeString(this.autre_motif, dos);

				// String

				writeString(this.information_evenement, dos);

				// String

				writeString(this.montant, dos);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.date_debut, dos);

				// String

				writeString(this.date_fin, dos);

				// String

				writeString(this.id_beneficiaire, dos);

				// String

				writeString(this.identite, dos);

				// String

				writeString(this.prenom, dos);

				// String

				writeString(this.beneficiaire_categorie_code, dos);

				// String

				writeString(this.beneficiaire_categorie, dos);

				// String

				writeString(this.beneficiaire_type_code, dos);

				// String

				writeString(this.beneficiaire_type, dos);

				// String

				writeString(this.beneficiaire_identifiant, dos);

				// String

				writeString(this.beneficiaire_profession_code, dos);

				// String

				writeString(this.profession_libelle, dos);

				// String

				writeString(this.structure_exercice, dos);

				// String

				writeString(this.pays_code, dos);

				// String

				writeString(this.adresse, dos);

				// String

				writeString(this.code_postal, dos);

				// String

				writeString(this.ville, dos);

				// String

				writeString(this.demande_de_rectification, dos);

				// String

				writeString(this.statut, dos);

				// String

				writeString(this.date_publication, dos);

				// String

				writeString(this.date_transmission, dos);

				// String

				writeString(this.raison_sociale, dos);

				// String

				writeString(this.secteur_activite, dos);

				// String

				writeString(this.entr_ville, dos);

				// String

				writeString(this.entr_dep_name, dos);

				// String

				writeString(this.entr_reg_name, dos);

				// String

				writeString(this.entreprise_nom_pays, dos);

				// String

				writeString(this.mere_id, dos);

				// String

				writeString(this.code_postal_entreprise, dos);

				// String

				writeString(this.numero_siren, dos);

				// String

				writeString(this.ville_sanscedex, dos);

				// String

				writeString(this.geom, dos);

				// String

				writeString(this.com_name, dos);

				// String

				writeString(this.com_code, dos);

				// String

				writeString(this.epci_name, dos);

				// String

				writeString(this.epci_code, dos);

				// String

				writeString(this.dep_code, dos);

				// String

				writeString(this.dep_name, dos);

				// String

				writeString(this.reg_code, dos);

				// String

				writeString(this.reg_name, dos);

				// String

				writeString(this.beneficiaire_nom_prenom_com_name, dos);

				// String

				writeString(this.semestre_annee, dos);

				// String

				writeString(this.beneficiaire_nom_pays, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",token=" + token);
			sb.append(",entreprise_id=" + entreprise_id);
			sb.append(",lien_interet=" + lien_interet);
			sb.append(",identifiant_unique=" + identifiant_unique);
			sb.append(",convention_liee=" + convention_liee);
			sb.append(",motif_lien_interet_code=" + motif_lien_interet_code);
			sb.append(",motif_lien_interet=" + motif_lien_interet);
			sb.append(",autre_motif=" + autre_motif);
			sb.append(",information_evenement=" + information_evenement);
			sb.append(",montant=" + montant);
			sb.append(",date=" + date);
			sb.append(",date_debut=" + date_debut);
			sb.append(",date_fin=" + date_fin);
			sb.append(",id_beneficiaire=" + id_beneficiaire);
			sb.append(",identite=" + identite);
			sb.append(",prenom=" + prenom);
			sb.append(",beneficiaire_categorie_code=" + beneficiaire_categorie_code);
			sb.append(",beneficiaire_categorie=" + beneficiaire_categorie);
			sb.append(",beneficiaire_type_code=" + beneficiaire_type_code);
			sb.append(",beneficiaire_type=" + beneficiaire_type);
			sb.append(",beneficiaire_identifiant=" + beneficiaire_identifiant);
			sb.append(",beneficiaire_profession_code=" + beneficiaire_profession_code);
			sb.append(",profession_libelle=" + profession_libelle);
			sb.append(",structure_exercice=" + structure_exercice);
			sb.append(",pays_code=" + pays_code);
			sb.append(",adresse=" + adresse);
			sb.append(",code_postal=" + code_postal);
			sb.append(",ville=" + ville);
			sb.append(",demande_de_rectification=" + demande_de_rectification);
			sb.append(",statut=" + statut);
			sb.append(",date_publication=" + date_publication);
			sb.append(",date_transmission=" + date_transmission);
			sb.append(",raison_sociale=" + raison_sociale);
			sb.append(",secteur_activite=" + secteur_activite);
			sb.append(",entr_ville=" + entr_ville);
			sb.append(",entr_dep_name=" + entr_dep_name);
			sb.append(",entr_reg_name=" + entr_reg_name);
			sb.append(",entreprise_nom_pays=" + entreprise_nom_pays);
			sb.append(",mere_id=" + mere_id);
			sb.append(",code_postal_entreprise=" + code_postal_entreprise);
			sb.append(",numero_siren=" + numero_siren);
			sb.append(",ville_sanscedex=" + ville_sanscedex);
			sb.append(",geom=" + geom);
			sb.append(",com_name=" + com_name);
			sb.append(",com_code=" + com_code);
			sb.append(",epci_name=" + epci_name);
			sb.append(",epci_code=" + epci_code);
			sb.append(",dep_code=" + dep_code);
			sb.append(",dep_name=" + dep_name);
			sb.append(",reg_code=" + reg_code);
			sb.append(",reg_name=" + reg_name);
			sb.append(",beneficiaire_nom_prenom_com_name=" + beneficiaire_nom_prenom_com_name);
			sb.append(",semestre_annee=" + semestre_annee);
			sb.append(",beneficiaire_nom_pays=" + beneficiaire_nom_pays);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tFileOutputDelimited_1 = 0;

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						"C:/Users/Ahmed.KHELLADI/Documents/Data_Science_7/Data_Integration_Project/Raw_Data/test2.xml"))
								.getAbsolutePath().replace("\\", "/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
							fileName_tFileOutputDelimited_1.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */
						";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
																		 * Start field
																		 * tFileOutputDelimited_1:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						dir_tFileOutputDelimited_1.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				if (fileToDelete_tFileOutputDelimited_1.exists()) {
					fileToDelete_tFileOutputDelimited_1.delete();
				}
				outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false), "UTF-8"));
				if (filetFileOutputDelimited_1.length() == 0) {
					outtFileOutputDelimited_1.write("id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("token");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("entreprise_id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("lien_interet");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("identifiant_unique");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("convention_liee");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("motif_lien_interet_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("motif_lien_interet");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("autre_motif");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("information_evenement");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("montant");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date_debut");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date_fin");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("id_beneficiaire");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("identite");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("prenom");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_categorie_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_categorie");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_type_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_type");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_identifiant");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_profession_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("profession_libelle");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("structure_exercice");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("pays_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("adresse");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("code_postal");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("ville");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("demande_de_rectification");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("statut");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date_publication");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date_transmission");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("raison_sociale");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("secteur_activite");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("entr_ville");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("entr_dep_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("entr_reg_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("entreprise_nom_pays");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("mere_id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("code_postal_entreprise");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("numero_siren");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("ville_sanscedex");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("geom");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("com_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("com_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("epci_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("epci_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("dep_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("dep_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("reg_code");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("reg_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_nom_prenom_com_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("semestre_annee");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("beneficiaire_nom_pays");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("errorMessage");
					outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tFilterRow_1 begin ] start
				 */

				ok_Hash.put("tFilterRow_1", false);
				start_Hash.put("tFilterRow_1", System.currentTimeMillis());

				currentComponent = "tFilterRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tFilterRow_1 = 0;

				int nb_line_tFilterRow_1 = 0;
				int nb_line_ok_tFilterRow_1 = 0;
				int nb_line_reject_tFilterRow_1 = 0;

				class Operator_tFilterRow_1 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_1(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/Ahmed.KHELLADI/Documents/Data_Science_7/Data_Integration_Project/Raw_Data/declarations.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Ahmed.KHELLADI/Documents/Data_Science_7/Data_Integration_Project/Raw_Data/declarations.csv",
								"UTF-8", ";", "\n", true, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row1.id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"id", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}

							} else {

								row1.id = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							row1.token = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 2;

							row1.entreprise_id = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 3;

							row1.lien_interet = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 4;

							row1.identifiant_unique = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 5;

							row1.convention_liee = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 6;

							row1.motif_lien_interet_code = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 7;

							row1.motif_lien_interet = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 8;

							row1.autre_motif = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 9;

							row1.information_evenement = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 10;

							row1.montant = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 11;

							row1.date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 12;

							row1.date_debut = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 13;

							row1.date_fin = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 14;

							row1.id_beneficiaire = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 15;

							row1.identite = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 16;

							row1.prenom = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 17;

							row1.beneficiaire_categorie_code = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 18;

							row1.beneficiaire_categorie = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 19;

							row1.beneficiaire_type_code = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 20;

							row1.beneficiaire_type = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 21;

							row1.beneficiaire_identifiant = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 22;

							row1.beneficiaire_profession_code = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 23;

							row1.profession_libelle = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 24;

							row1.structure_exercice = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 25;

							row1.pays_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 26;

							row1.adresse = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 27;

							row1.code_postal = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 28;

							row1.ville = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 29;

							row1.demande_de_rectification = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 30;

							row1.statut = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 31;

							row1.date_publication = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 32;

							row1.date_transmission = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 33;

							row1.raison_sociale = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 34;

							row1.secteur_activite = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 35;

							row1.entr_ville = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 36;

							row1.entr_dep_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 37;

							row1.entr_reg_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 38;

							row1.entreprise_nom_pays = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 39;

							row1.mere_id = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 40;

							row1.code_postal_entreprise = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 41;

							row1.numero_siren = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 42;

							row1.ville_sanscedex = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 43;

							row1.geom = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 44;

							row1.com_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 45;

							row1.com_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 46;

							row1.epci_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 47;

							row1.epci_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 48;

							row1.dep_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 49;

							row1.dep_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 50;

							row1.reg_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 51;

							row1.reg_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 52;

							row1.beneficiaire_nom_prenom_com_name = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 53;

							row1.semestre_annee = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 54;

							row1.beneficiaire_nom_pays = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row1 = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {
							row2 = null;

							/**
							 * [tFilterRow_1 main ] start
							 */

							currentComponent = "tFilterRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							row2 = null;
							Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
							ope_tFilterRow_1.matches((// code sample : use row1 to define the condition.
// row1.columnName1.equals("foo") ||!(row1.columnName2.equals("bar"))
// replace the following expression by your own filter condition 
							StringHandling.LEN(row1.montant) < 11

							), "advanced condition failed");

							if (ope_tFilterRow_1.getMatchFlag()) {
								nb_line_ok_tFilterRow_1++;
							} else {
								if (row2 == null) {
									row2 = new row2Struct();
								}
								row2.id = row1.id;
								row2.token = row1.token;
								row2.entreprise_id = row1.entreprise_id;
								row2.lien_interet = row1.lien_interet;
								row2.identifiant_unique = row1.identifiant_unique;
								row2.convention_liee = row1.convention_liee;
								row2.motif_lien_interet_code = row1.motif_lien_interet_code;
								row2.motif_lien_interet = row1.motif_lien_interet;
								row2.autre_motif = row1.autre_motif;
								row2.information_evenement = row1.information_evenement;
								row2.montant = row1.montant;
								row2.date = row1.date;
								row2.date_debut = row1.date_debut;
								row2.date_fin = row1.date_fin;
								row2.id_beneficiaire = row1.id_beneficiaire;
								row2.identite = row1.identite;
								row2.prenom = row1.prenom;
								row2.beneficiaire_categorie_code = row1.beneficiaire_categorie_code;
								row2.beneficiaire_categorie = row1.beneficiaire_categorie;
								row2.beneficiaire_type_code = row1.beneficiaire_type_code;
								row2.beneficiaire_type = row1.beneficiaire_type;
								row2.beneficiaire_identifiant = row1.beneficiaire_identifiant;
								row2.beneficiaire_profession_code = row1.beneficiaire_profession_code;
								row2.profession_libelle = row1.profession_libelle;
								row2.structure_exercice = row1.structure_exercice;
								row2.pays_code = row1.pays_code;
								row2.adresse = row1.adresse;
								row2.code_postal = row1.code_postal;
								row2.ville = row1.ville;
								row2.demande_de_rectification = row1.demande_de_rectification;
								row2.statut = row1.statut;
								row2.date_publication = row1.date_publication;
								row2.date_transmission = row1.date_transmission;
								row2.raison_sociale = row1.raison_sociale;
								row2.secteur_activite = row1.secteur_activite;
								row2.entr_ville = row1.entr_ville;
								row2.entr_dep_name = row1.entr_dep_name;
								row2.entr_reg_name = row1.entr_reg_name;
								row2.entreprise_nom_pays = row1.entreprise_nom_pays;
								row2.mere_id = row1.mere_id;
								row2.code_postal_entreprise = row1.code_postal_entreprise;
								row2.numero_siren = row1.numero_siren;
								row2.ville_sanscedex = row1.ville_sanscedex;
								row2.geom = row1.geom;
								row2.com_name = row1.com_name;
								row2.com_code = row1.com_code;
								row2.epci_name = row1.epci_name;
								row2.epci_code = row1.epci_code;
								row2.dep_code = row1.dep_code;
								row2.dep_name = row1.dep_name;
								row2.reg_code = row1.reg_code;
								row2.reg_name = row1.reg_name;
								row2.beneficiaire_nom_prenom_com_name = row1.beneficiaire_nom_prenom_com_name;
								row2.semestre_annee = row1.semestre_annee;
								row2.beneficiaire_nom_pays = row1.beneficiaire_nom_pays;
								row2.errorMessage = ope_tFilterRow_1.getErrorMsg();
								nb_line_reject_tFilterRow_1++;
							}

							nb_line_tFilterRow_1++;

							tos_count_tFilterRow_1++;

							/**
							 * [tFilterRow_1 main ] stop
							 */

							/**
							 * [tFilterRow_1 process_data_begin ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_begin ] stop
							 */
// Start of branch "row2"
							if (row2 != null) {

								/**
								 * [tFileOutputDelimited_1 main ] start
								 */

								currentComponent = "tFileOutputDelimited_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row2"

									);
								}

								StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
								if (row2.id != null) {
									sb_tFileOutputDelimited_1.append(row2.id);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.token != null) {
									sb_tFileOutputDelimited_1.append(row2.token);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.entreprise_id != null) {
									sb_tFileOutputDelimited_1.append(row2.entreprise_id);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.lien_interet != null) {
									sb_tFileOutputDelimited_1.append(row2.lien_interet);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.identifiant_unique != null) {
									sb_tFileOutputDelimited_1.append(row2.identifiant_unique);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.convention_liee != null) {
									sb_tFileOutputDelimited_1.append(row2.convention_liee);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.motif_lien_interet_code != null) {
									sb_tFileOutputDelimited_1.append(row2.motif_lien_interet_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.motif_lien_interet != null) {
									sb_tFileOutputDelimited_1.append(row2.motif_lien_interet);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.autre_motif != null) {
									sb_tFileOutputDelimited_1.append(row2.autre_motif);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.information_evenement != null) {
									sb_tFileOutputDelimited_1.append(row2.information_evenement);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.montant != null) {
									sb_tFileOutputDelimited_1.append(row2.montant);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.date != null) {
									sb_tFileOutputDelimited_1.append(row2.date);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.date_debut != null) {
									sb_tFileOutputDelimited_1.append(row2.date_debut);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.date_fin != null) {
									sb_tFileOutputDelimited_1.append(row2.date_fin);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.id_beneficiaire != null) {
									sb_tFileOutputDelimited_1.append(row2.id_beneficiaire);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.identite != null) {
									sb_tFileOutputDelimited_1.append(row2.identite);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.prenom != null) {
									sb_tFileOutputDelimited_1.append(row2.prenom);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_categorie_code != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_categorie_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_categorie != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_categorie);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_type_code != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_type_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_type != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_type);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_identifiant != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_identifiant);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_profession_code != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_profession_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.profession_libelle != null) {
									sb_tFileOutputDelimited_1.append(row2.profession_libelle);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.structure_exercice != null) {
									sb_tFileOutputDelimited_1.append(row2.structure_exercice);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.pays_code != null) {
									sb_tFileOutputDelimited_1.append(row2.pays_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.adresse != null) {
									sb_tFileOutputDelimited_1.append(row2.adresse);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.code_postal != null) {
									sb_tFileOutputDelimited_1.append(row2.code_postal);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.ville != null) {
									sb_tFileOutputDelimited_1.append(row2.ville);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.demande_de_rectification != null) {
									sb_tFileOutputDelimited_1.append(row2.demande_de_rectification);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.statut != null) {
									sb_tFileOutputDelimited_1.append(row2.statut);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.date_publication != null) {
									sb_tFileOutputDelimited_1.append(row2.date_publication);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.date_transmission != null) {
									sb_tFileOutputDelimited_1.append(row2.date_transmission);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.raison_sociale != null) {
									sb_tFileOutputDelimited_1.append(row2.raison_sociale);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.secteur_activite != null) {
									sb_tFileOutputDelimited_1.append(row2.secteur_activite);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.entr_ville != null) {
									sb_tFileOutputDelimited_1.append(row2.entr_ville);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.entr_dep_name != null) {
									sb_tFileOutputDelimited_1.append(row2.entr_dep_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.entr_reg_name != null) {
									sb_tFileOutputDelimited_1.append(row2.entr_reg_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.entreprise_nom_pays != null) {
									sb_tFileOutputDelimited_1.append(row2.entreprise_nom_pays);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.mere_id != null) {
									sb_tFileOutputDelimited_1.append(row2.mere_id);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.code_postal_entreprise != null) {
									sb_tFileOutputDelimited_1.append(row2.code_postal_entreprise);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.numero_siren != null) {
									sb_tFileOutputDelimited_1.append(row2.numero_siren);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.ville_sanscedex != null) {
									sb_tFileOutputDelimited_1.append(row2.ville_sanscedex);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.geom != null) {
									sb_tFileOutputDelimited_1.append(row2.geom);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.com_name != null) {
									sb_tFileOutputDelimited_1.append(row2.com_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.com_code != null) {
									sb_tFileOutputDelimited_1.append(row2.com_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.epci_name != null) {
									sb_tFileOutputDelimited_1.append(row2.epci_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.epci_code != null) {
									sb_tFileOutputDelimited_1.append(row2.epci_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.dep_code != null) {
									sb_tFileOutputDelimited_1.append(row2.dep_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.dep_name != null) {
									sb_tFileOutputDelimited_1.append(row2.dep_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.reg_code != null) {
									sb_tFileOutputDelimited_1.append(row2.reg_code);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.reg_name != null) {
									sb_tFileOutputDelimited_1.append(row2.reg_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_nom_prenom_com_name != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_nom_prenom_com_name);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.semestre_annee != null) {
									sb_tFileOutputDelimited_1.append(row2.semestre_annee);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.beneficiaire_nom_pays != null) {
									sb_tFileOutputDelimited_1.append(row2.beneficiaire_nom_pays);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
								if (row2.errorMessage != null) {
									sb_tFileOutputDelimited_1.append(row2.errorMessage);
								}
								sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

								nb_line_tFileOutputDelimited_1++;
								resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

								outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());

								tos_count_tFileOutputDelimited_1++;

								/**
								 * [tFileOutputDelimited_1 main ] stop
								 */

								/**
								 * [tFileOutputDelimited_1 process_data_begin ] start
								 */

								currentComponent = "tFileOutputDelimited_1";

								/**
								 * [tFileOutputDelimited_1 process_data_begin ] stop
								 */

								/**
								 * [tFileOutputDelimited_1 process_data_end ] start
								 */

								currentComponent = "tFileOutputDelimited_1";

								/**
								 * [tFileOutputDelimited_1 process_data_end ] stop
								 */

							} // End of branch "row2"

							/**
							 * [tFilterRow_1 process_data_end ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C:/Users/Ahmed.KHELLADI/Documents/Data_Science_7/Data_Integration_Project/Raw_Data/declarations.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tFilterRow_1 end ] start
				 */

				currentComponent = "tFilterRow_1";

				globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tFilterRow_1", true);
				end_Hash.put("tFilterRow_1", System.currentTimeMillis());

				/**
				 * [tFilterRow_1 end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (outtFileOutputDelimited_1 != null) {
					outtFileOutputDelimited_1.flush();
					outtFileOutputDelimited_1.close();
				}

				globalMap.put("tFileOutputDelimited_1_NB_LINE", nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tFilterRow_1 finally ] start
				 */

				currentComponent = "tFilterRow_1";

				/**
				 * [tFilterRow_1 finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_1");
					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Copy_of_Transparencesantemain Copy_of_TransparencesantemainClass = new Copy_of_Transparencesantemain();

		int exitCode = Copy_of_TransparencesantemainClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = Copy_of_Transparencesantemain.class.getClassLoader().getResourceAsStream(
					"data_integration4/copy_of_transparencesantemain_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = Copy_of_Transparencesantemain.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : Copy_of_Transparencesantemain");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 143670 characters generated by Talend Open Studio for Data Integration on the
 * 9 novembre 2022 à 14:46:55 CET
 ************************************************************************************************/